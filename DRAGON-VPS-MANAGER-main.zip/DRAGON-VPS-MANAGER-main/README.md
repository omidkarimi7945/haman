## ◇────── DRAGON VPS MANAGER ───────◇

ㅤ
<p align="left">
  <a href="" rel="noopener">
 <img width=550px height=550px src="https://github.com/januda-ui/januda-ui/blob/main/icons/photo_2021-12-01_07-36-12.jpg?raw=true?raw=true" alt="logo"></a>
</p>

##
___REFERRAL LINK___

[![DigitalOcean Referral Badge](https://web-platforms.sfo2.cdn.digitaloceanspaces.com/WWW/Badge%201.svg)](https://www.digitalocean.com/?refcode=0c8d9b763684&utm_campaign=Referral_Invite&utm_medium=Referral_Program&utm_source=badge)

## ㅤ

___Update System Packages and Install SCRIPT___

```
apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/januda-ui/DRAGON-VPS-MANAGER/main/hehe; chmod 777 hehe;./hehe

```

## ㅤ

___Tutorial___

<P>
<div class="div1">
<span><a href="https://player.vimeo.com/video/652289751"><img src="https://user-images.githubusercontent.com/83800532/144345002-c3ec5251-f723-4a81-bcaa-ad4579562218.png" alt=""width="50"height="50"/></a></span>
<span><a href="https://t.me/dragon_vps_manager/18"><img src="https://user-images.githubusercontent.com/83800532/143560346-101a5bbb-53c6-4d1d-90c9-364c3355a6b7.png" alt=""width="50"height="50"/></a></span>
</div>
</P>
  

## ㅤ

___Screenshots___

<details>
  <summary><p><b>Click To View [Terminal] </b><div class="div0"> <span><a href=""><img src="https://user-images.githubusercontent.com/83800532/143572065-ca450924-e72b-4041-ab31-3798618973f4.png" alt=""width="30"height="30"/><span><a href=""><img src="https://user-images.githubusercontent.com/83800532/144479843-ab04c6b5-9514-4863-b714-a1b391f42b27.png" alt=""width="30"height="30"/></a></span></p></summary></div>
<br/>

<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_ss_1.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_ss2.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_ss_3.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_ss_4.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_vps_5.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/dragon_ss_6.png" alt=""/></span></p>
</details>


<details>
  <summary><p><b>Click To View [Telegram Bot]</b><div class="div0"> <span><a href=""><img src="https://user-images.githubusercontent.com/83800532/143572065-ca450924-e72b-4041-ab31-3798618973f4.png" alt=""width="30"height="30"/><span><a href=""><img src="https://user-images.githubusercontent.com/83800532/143560346-101a5bbb-53c6-4d1d-90c9-364c3355a6b7.png" alt=""width="30"height="30"/></a></span></p></summary></div>
<br/>

<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/ss4.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/ss3.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/ss1.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/ss2.png" alt=""/></span></p>
<p><span><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/Screenshot%20(41).png" alt=""/></span></p>
</details>


## ㅤ

___Based on___

 <p>    
<div class="div1">
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/icons8-linux.gif?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/icons8-internet.gif?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/ubuntu.gif?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/icons8-ssh-48.png?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/terminal2.gif?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href="https://github.com/NT-GIT-HUB/VPS-MANAGER-1.0"><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/business-3d-browser-1.png?raw=true" alt=""width="50"height="50"/></a></span>
  <span><a href=""><img src="https://github.com/januda-ui/januda-ui/blob/main/icons/clip-internet-security.png?raw=true" alt=""width="50"height="50"/></a></span>
</div>
 </p>
 
 ## ㅤ
 
___Credits___

<p>see on <a href="https://github.com/januda-ui/DRAGON-VPS-MANAGER/wiki/Credits" target="_blank" rel="noopener">wiki</a></p>
<p>see on <a href="https://telegra.ph/DRAGON-VPS-MANAGER-11-30" target="_blank" rel="noopener">Telegra.ph</a>&nbsp;</p>
  <P><b><i> 💐💐 To everyone who gave me advice and ideas.💐💐 </i></b></p>

## ㅤ

___Follow Us!___

 <p>    
<div class="div2">
 <span><a href="https://t.me/s/dragon_vps_manager"><img src="https://user-images.githubusercontent.com/83800532/143560346-101a5bbb-53c6-4d1d-90c9-364c3355a6b7.png" alt=""width="50"height="50"/></a></span>
 </div>
 </p>
 
## ㅤ
 
___⚠️ Announcement ⚠️___

<p><i>This script is not our own <a href="https://t.me/s/singledevelopers/">@SingleDevelopers</a> creation and we will be working on providing our own script soon.<i></p>

 
##  ㅤ

___Licence___

[![License](https://www.gnu.org/graphics/gplv3-127x51.png)](LICENSE)

